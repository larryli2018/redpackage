声明：本系统为本人自娱自乐基于酷信开发的控制系统，不用于任何非法用途。下载用户，请勿用于非法获取，仅供大家娱乐。
1.测试环境使用的centos7.8 64位
2.确保jdk1.8环境
3.在阿里云的端口管理，授权你自己的服务器ip或任何服务器都可以访问6379，9876可以访问。
4.在阿里云的云mongodb数据库申请开启外网访问（如果用的本地mongodb数据库，在端口开启28018端口）
5.使用FileZila上传文件到服务器的/opt目录下面
6.安装jdk
使用ssh远程到服务器
ssh root@ip
输入密码进入系统
yum install zip unzip
cd  /opt
unzip jdk1.8.0_131.zip
mkdir  java
mv  jdk1.8.0_131  ./java


vi /etc/profile
将下面的内容输入到文件尾部
JAVA_HOME=/opt/java/jdk1.8.0_131
JRE_HOME=/opt/java/jdk1.8.0_131/jre
CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar:$JRE_HOME/lib
PATH=$JAVA_HOME/bin:$PATH
export PATH JAVA_HOME CLASSPATH

#更新环境变量
source /etc/profile

#查看是否安装成功
java -version
7.安装redhelper
unzip redhelper.zip 
 cd redhelper

#编辑配置文件
 vi application.properties
 #端口可以自己随意改，改了要确保阿里云的该端口有开放
 server.port=8080
 #如果本地数据库，使用这个配置
 mongoconfig.uri=mongodb://聊天服务器的外网ip:28018
 如果是用的云数据库，配置类似这样：
 mongodb://root:数据库密码@主服务器,副服务器/admin?replicaSet=xxxx
 #redis也配置为对应外网服务器的ip
 redisson.address=redis://redis所在服务器的外网ip:6379
 #消息服务器和消息队列服务器配置对应外网ip
 im.mqConfig.nameAddr=127.0.0.1:9876
rocketmq.name-server=127.0.0.1:9876
保存配置文件

8.启动运行
sh start


unzip imapi.war -d imapi
cp digit-1.0-SNAPSHOT.jar /opt/spring-boot-imapi-jiqun/imapi/WEB-INF/lib/
/opt/spring-boot-imapi-jiqun/imapi/WEB-INF/lib
mv imapi.war imapi.war.bak
zip -r imapi.war ./imapi



mkdir imapi
cp imapi.war ./imapi
cd imapi
jar -xvf imapi.war 
rm -rf imapi.war
cd ..
cp digit-1.0-SNAPSHOT.jar /opt/spring-boot-imapi-jiqun/imapi/WEB-INF/lib/
rm -rf imapi.war
jar -cvfM0 imapi.war ./


cd /opt
jar -xvf imapi.war WEB-INF/lib/digit-1.0-SNAPSHOT.jar
cp digit-1.0-SNAPSHOT.jar ./WEB-INF/lib/
jar -uvf imapi.war WEB-INF/lib/digit-1.0-SNAPSHOT.jar


mvn install:install-file -Dfile=/Users/.../digit-1.0-SNAPSHOT.jar  -DgroupId=com.dev -DartifactId=digit -Dversion=1.0-SNAPSHOT -Dpackaging=jar


